package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.lyrics.LrcParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AuraMP3", appName)
    }

    @Test
    fun `parse synchronized lrc lyrics`() {
        val rawLrc = """
            [00:04.50] Luces de neón en la ciudad
            [00:12.80] Sintetizadores fluyendo en mi mente
        """.trimIndent()

        val lines = LrcParser.parse(rawLrc)
        assertEquals(2, lines.size)
        assertEquals(4500L, lines[0].timeMs)
        assertEquals("Luces de neón en la ciudad", lines[0].text)

        val activeIdx = LrcParser.findActiveIndex(lines, 5000L)
        assertEquals(0, activeIdx)

        val activeIdx2 = LrcParser.findActiveIndex(lines, 15000L)
        assertEquals(1, activeIdx2)
    }

    @Test
    fun `verify song sharing intent trigger`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val testSong = com.example.model.Song(
            id = "test_song_01",
            title = "Neon Pulse",
            artist = "Synthwave Dreams",
            album = "Retro 1984",
            genre = "Synthwave",
            durationMs = 36000L,
            filePath = "/fake/path/song.wav"
        )

        // Verifies ShareHelper handles file gracefully without throwing exceptions
        com.example.util.ShareHelper.shareSong(context, testSong)

        val testPlaylist = com.example.model.Playlist(
            id = "test_pl",
            name = "Favoritas 8D",
            description = "Las mejores canciones",
            songIds = listOf("test_song_01")
        )
        com.example.util.ShareHelper.sharePlaylist(context, testPlaylist, listOf(testSong))
    }
}
