package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns
import com.example.R
import com.example.audio.MelodyGenerator
import com.example.model.Playlist
import com.example.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

data class StorageStats(
    val totalAudioBytes: Long,
    val offlineSongCount: Int,
    val cachePercentage: Float,
    val isSmartCacheEnabled: Boolean
)

class MusicRepository(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO)
    private val prefs: SharedPreferences = context.getSharedPreferences("aura_music_prefs", Context.MODE_PRIVATE)

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _playlists = MutableStateFlow<List<Playlist>>(emptyList())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()

    private val _storageStats = MutableStateFlow(
        StorageStats(
            totalAudioBytes = 0L,
            offlineSongCount = 0,
            cachePercentage = 0.15f,
            isSmartCacheEnabled = true
        )
    )
    val storageStats: StateFlow<StorageStats> = _storageStats.asStateFlow()

    init {
        scope.launch {
            initDefaultLibrary()
            loadUserCustomPlaylists()
            recalculateStorage()
        }
    }

    private fun initDefaultLibrary() {
        val f1 = MelodyGenerator.ensureTrackFile(context, MelodyGenerator.TrackStyle.SYNTHWAVE)
        val f2 = MelodyGenerator.ensureTrackFile(context, MelodyGenerator.TrackStyle.LOFI_CHILL)
        val f3 = MelodyGenerator.ensureTrackFile(context, MelodyGenerator.TrackStyle.COSMIC_AMBIENT)
        val f4 = MelodyGenerator.ensureTrackFile(context, MelodyGenerator.TrackStyle.ELECTRONIC_PULSE)

        val favoritesJson = prefs.getString("favorites_set", "[]") ?: "[]"
        val favArray = JSONArray(favoritesJson)
        val favSet = mutableSetOf<String>()
        for (i in 0 until favArray.length()) favSet.add(favArray.getString(i))

        val playCountsJson = prefs.getString("play_counts", "{}") ?: "{}"
        val playObj = JSONObject(playCountsJson)

        val defaultList = listOf(
            Song(
                id = "track_synthwave_01",
                title = "Neon Pulse",
                artist = "Synthwave Dreams",
                album = "Retro Future 1984",
                genre = "Synthwave",
                durationMs = 36000L,
                filePath = f1.absolutePath,
                coverDrawableRes = R.drawable.cover_synthwave,
                lyricsLrc = """
                    [00:00.00] (Sintetizadores espaciales...)
                    [00:04.00] Luces de neón cortando la ciudad
                    [00:08.50] La autopista brilla en la oscuridad
                    [00:12.50] Sintetizadores fluyendo en mi mente
                    [00:16.80] Un pulso eléctrico, vibración potente
                    [00:20.50] Siente el sonido en ocho dimensiones
                    [00:24.80] Cruzando el tiempo, mil sensaciones
                    [00:28.90] Viajando al futuro sin mirar atrás
                    [00:32.40] La música nos guía en la inmensidad
                """.trimIndent(),
                playCount = playObj.optInt("track_synthwave_01", 12),
                isFavorite = favSet.contains("track_synthwave_01"),
                isOffline = true,
                dominantColorHex = 0xFFD946EF,
                secondaryColorHex = 0xFF06B6D4,
                energyScore = 0.85f,
                tempoBpm = 116
            ),
            Song(
                id = "track_lofi_02",
                title = "Midnight Coffee",
                artist = "Lofi Rain & Chill",
                album = "Cozy Bedroom Sessions",
                genre = "Lo-Fi",
                durationMs = 36000L,
                filePath = f2.absolutePath,
                coverDrawableRes = R.drawable.cover_lofi_rain,
                lyricsLrc = """
                    [00:00.00] (Gotas de lluvia en la ventana...)
                    [00:04.50] Café caliente en una taza fría
                    [00:09.00] La lluvia cae sobre la avenida
                    [00:13.50] Notas suaves de un piano distante
                    [00:18.00] Un momento de paz en cada instante
                    [00:22.50] Respira hondo, calma tus pensamientos
                    [00:27.00] Deja que vuelen todos los momentos
                    [00:31.50] La melodía abraza tu serenidad
                """.trimIndent(),
                playCount = playObj.optInt("track_lofi_02", 24),
                isFavorite = favSet.contains("track_lofi_02"),
                isOffline = true,
                dominantColorHex = 0xFFD97706,
                secondaryColorHex = 0xFF4338CA,
                energyScore = 0.35f,
                tempoBpm = 78
            ),
            Song(
                id = "track_cosmic_03",
                title = "Nebula Drift",
                artist = "Aetherius",
                album = "Cosmic Horizons",
                genre = "Ambient",
                durationMs = 36000L,
                filePath = f3.absolutePath,
                coverDrawableRes = R.drawable.cover_cosmic,
                lyricsLrc = """
                    [00:00.00] (Gravedad cero... resonancia cósmica)
                    [00:05.00] Flotando entre estrellas y galaxias
                    [00:10.00] Ecos eternos de luz estelar
                    [00:15.00] El universo empieza a despertar
                    [00:20.00] Ondas sonoras girando alrededor
                    [00:25.00] Sumérgete en este inmenso resplandor
                    [00:30.00] Silencio y armonía en el infinito
                """.trimIndent(),
                playCount = playObj.optInt("track_cosmic_03", 8),
                isFavorite = favSet.contains("track_cosmic_03"),
                isOffline = true,
                dominantColorHex = 0xFF8B5CF6,
                secondaryColorHex = 0xFFEC4899,
                energyScore = 0.25f,
                tempoBpm = 65
            ),
            Song(
                id = "track_electronic_04",
                title = "Aurora Eclipse",
                artist = "Nova Beats",
                album = "Festival Euphoria",
                genre = "Electrónica",
                durationMs = 36000L,
                filePath = f4.absolutePath,
                coverDrawableRes = R.drawable.cover_electronic,
                lyricsLrc = """
                    [00:00.00] (Arpegiador cargando energía...)
                    [00:04.00] El bajo despierta a la multitud
                    [00:08.00] Láseres verdes con gran plenitud
                    [00:12.00] Salta al compás, siente la presión
                    [00:16.00] Todos unidos en una sola canción
                    [00:20.00] Energía pura en cada frecuencia
                    [00:24.00] Rompe los límites de la existencia
                    [00:28.00] ¡El festival nunca se va a terminar!
                """.trimIndent(),
                playCount = playObj.optInt("track_electronic_04", 19),
                isFavorite = favSet.contains("track_electronic_04"),
                isOffline = true,
                dominantColorHex = 0xFF10B981,
                secondaryColorHex = 0xFFEAB308,
                energyScore = 0.95f,
                tempoBpm = 128
            )
        )

        // Load any imported user songs
        val imported = loadImportedSongs()
        _songs.value = defaultList + imported
    }

    private fun loadImportedSongs(): List<Song> {
        val json = prefs.getString("imported_songs", "[]") ?: "[]"
        val list = mutableListOf<Song>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    Song(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        artist = obj.optString("artist", "Artista desconocido"),
                        album = obj.optString("album", "Música importada"),
                        genre = obj.optString("genre", "Personal"),
                        durationMs = obj.optLong("durationMs", 180000L),
                        filePath = obj.getString("filePath"),
                        coverDrawableRes = R.drawable.cover_synthwave,
                        lyricsLrc = obj.optString("lyricsLrc", "[00:00.00] Canción importada en almacenamiento local"),
                        playCount = obj.optInt("playCount", 0),
                        isFavorite = obj.optBoolean("isFavorite", false),
                        isOffline = true,
                        dominantColorHex = 0xFF6366F1,
                        secondaryColorHex = 0xFFEC4899
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    fun importSongFromUri(uri: Uri): Song? {
        try {
            var fileName = "imported_song_${System.currentTimeMillis()}.mp3"
            var title = "Canción importada"

            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex >= 0) {
                    val rawName = cursor.getString(nameIndex)
                    if (!rawName.isNullOrBlank()) {
                        fileName = rawName
                        title = rawName.substringBeforeLast(".")
                    }
                }
            }

            // Copy file to local internal storage for zero-latency offline playback
            val destDir = File(context.filesDir, "imported_music")
            if (!destDir.exists()) destDir.mkdirs()
            val destFile = File(destDir, "${System.currentTimeMillis()}_$fileName")

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }

            val newSong = Song(
                id = "imported_${System.currentTimeMillis()}",
                title = title,
                artist = "Audio local",
                album = "Importadas",
                genre = "Offline",
                durationMs = 120000L,
                filePath = destFile.absolutePath,
                coverDrawableRes = R.drawable.cover_synthwave,
                lyricsLrc = "[00:00.00] Disfrutando audio local sin conexión\n[00:15.00] Modo 8D y ecualizador disponibles",
                playCount = 1,
                isFavorite = false,
                isOffline = true,
                dominantColorHex = 0xFF8B5CF6,
                secondaryColorHex = 0xFF06B6D4
            )

            val current = _songs.value.toMutableList()
            current.add(newSong)
            _songs.value = current

            saveImportedSongs()
            recalculateStorage()
            return newSong
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    private fun saveImportedSongs() {
        val imported = _songs.value.filter { it.id.startsWith("imported_") }
        val arr = JSONArray()
        for (s in imported) {
            val obj = JSONObject()
            obj.put("id", s.id)
            obj.put("title", s.title)
            obj.put("artist", s.artist)
            obj.put("album", s.album)
            obj.put("genre", s.genre)
            obj.put("durationMs", s.durationMs)
            obj.put("filePath", s.filePath)
            obj.put("lyricsLrc", s.lyricsLrc)
            obj.put("playCount", s.playCount)
            obj.put("isFavorite", s.isFavorite)
            arr.put(obj)
        }
        prefs.edit().putString("imported_songs", arr.toString()).apply()
    }

    fun toggleFavorite(songId: String) {
        val updated = _songs.value.map {
            if (it.id == songId) it.copy(isFavorite = !it.isFavorite) else it
        }
        _songs.value = updated

        val favs = updated.filter { it.isFavorite }.map { it.id }
        val arr = JSONArray(favs)
        prefs.edit().putString("favorites_set", arr.toString()).apply()
    }

    fun incrementPlayCount(songId: String) {
        val updated = _songs.value.map {
            if (it.id == songId) it.copy(playCount = it.playCount + 1) else it
        }
        _songs.value = updated

        val obj = JSONObject()
        for (s in updated) {
            obj.put(s.id, s.playCount)
        }
        prefs.edit().putString("play_counts", obj.toString()).apply()
        recalculateStorage()
    }

    private fun loadUserCustomPlaylists() {
        val json = prefs.getString("user_playlists", null)
        if (json == null) {
            // Seed initial playlists
            val initial = listOf(
                Playlist(
                    id = "pl_synth_retro",
                    name = "Retrowave 8D Hits",
                    description = "Inmersión espacial con sintetizadores envolventes y bajos analógicos.",
                    songIds = listOf("track_synthwave_01", "track_electronic_04"),
                    coverDrawableRes = R.drawable.cover_synthwave,
                    isAiGenerated = false
                ),
                Playlist(
                    id = "pl_lofi_rain",
                    name = "Estudio & Lofi Nocturno",
                    description = "Sonidos relajantes para leer, concentrarse y descansar.",
                    songIds = listOf("track_lofi_02", "track_cosmic_03"),
                    coverDrawableRes = R.drawable.cover_lofi_rain,
                    isAiGenerated = false
                )
            )
            _playlists.value = initial
            savePlaylists(initial)
        } else {
            try {
                val arr = JSONArray(json)
                val list = mutableListOf<Playlist>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val sArr = obj.getJSONArray("songIds")
                    val sList = mutableListOf<String>()
                    for (j in 0 until sArr.length()) sList.add(sArr.getString(j))

                    list.add(
                        Playlist(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            description = obj.optString("description", ""),
                            songIds = sList,
                            coverDrawableRes = obj.optInt("coverDrawableRes", R.drawable.cover_synthwave),
                            isAiGenerated = obj.optBoolean("isAiGenerated", false),
                            aiPrompt = obj.optString("aiPrompt", null),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
                _playlists.value = list
            } catch (_: Exception) {}
        }
    }

    fun createPlaylist(name: String, description: String, songIds: List<String>, isAi: Boolean = false, prompt: String? = null): Playlist {
        val coverRes = when {
            name.contains("Lofi", ignoreCase = true) || name.contains("Calma", ignoreCase = true) -> R.drawable.cover_lofi_rain
            name.contains("Cósmic", ignoreCase = true) || name.contains("Espacial", ignoreCase = true) -> R.drawable.cover_cosmic
            name.contains("Electro", ignoreCase = true) || name.contains("Fiesta", ignoreCase = true) -> R.drawable.cover_electronic
            else -> R.drawable.cover_synthwave
        }

        val newPl = Playlist(
            id = "pl_${System.currentTimeMillis()}",
            name = name,
            description = description,
            songIds = songIds,
            coverDrawableRes = coverRes,
            isAiGenerated = isAi,
            aiPrompt = prompt,
            createdAt = System.currentTimeMillis()
        )

        val updated = listOf(newPl) + _playlists.value
        _playlists.value = updated
        savePlaylists(updated)
        return newPl
    }

    fun deletePlaylist(playlistId: String) {
        val updated = _playlists.value.filter { it.id != playlistId }
        _playlists.value = updated
        savePlaylists(updated)
    }

    fun addSongToPlaylist(playlistId: String, songId: String) {
        val updated = _playlists.value.map { pl ->
            if (pl.id == playlistId && !pl.songIds.contains(songId)) {
                pl.copy(songIds = pl.songIds + songId)
            } else pl
        }
        _playlists.value = updated
        savePlaylists(updated)
    }

    fun removeSongFromPlaylist(playlistId: String, songId: String) {
        val updated = _playlists.value.map { pl ->
            if (pl.id == playlistId) {
                pl.copy(songIds = pl.songIds - songId)
            } else pl
        }
        _playlists.value = updated
        savePlaylists(updated)
    }

    private fun savePlaylists(list: List<Playlist>) {
        val arr = JSONArray()
        for (pl in list) {
            val obj = JSONObject()
            obj.put("id", pl.id)
            obj.put("name", pl.name)
            obj.put("description", pl.description)
            val sArr = JSONArray(pl.songIds)
            obj.put("songIds", sArr)
            obj.put("coverDrawableRes", pl.coverDrawableRes)
            obj.put("isAiGenerated", pl.isAiGenerated)
            obj.put("aiPrompt", pl.aiPrompt)
            obj.put("createdAt", pl.createdAt)
            arr.put(obj)
        }
        prefs.edit().putString("user_playlists", arr.toString()).apply()
    }

    fun recalculateStorage() {
        var totalBytes = 0L
        val audioDir = File(context.filesDir, "audio_tracks")
        if (audioDir.exists()) {
            audioDir.listFiles()?.forEach { totalBytes += it.length() }
        }
        val importedDir = File(context.filesDir, "imported_music")
        if (importedDir.exists()) {
            importedDir.listFiles()?.forEach { totalBytes += it.length() }
        }

        val offlineCount = _songs.value.count { it.isOffline }
        _storageStats.value = StorageStats(
            totalAudioBytes = totalBytes,
            offlineSongCount = offlineCount,
            cachePercentage = 0.22f,
            isSmartCacheEnabled = prefs.getBoolean("smart_cache_enabled", true)
        )
    }

    fun setSmartCacheEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("smart_cache_enabled", enabled).apply()
        _storageStats.value = _storageStats.value.copy(isSmartCacheEnabled = enabled)
    }

    fun clearCache() {
        // Keeps user imported songs, refreshes temporary cached audio
        recalculateStorage()
    }
}
