package com.example.lyrics

import com.example.model.LyricLine
import java.util.regex.Pattern

object LrcParser {
    private val timePattern = Pattern.compile("\\[(\\d{2}):(\\d{2})(?:[.:](\\d{2,3}))?\\]")

    fun parse(lrcText: String): List<LyricLine> {
        if (lrcText.isBlank()) return emptyList()

        val lines = mutableListOf<LyricLine>()
        val rawLines = lrcText.lines()

        for (line in rawLines) {
            val trimmed = line.trim()
            if (trimmed.isEmpty()) continue

            val matcher = timePattern.matcher(trimmed)
            val timeStamps = mutableListOf<Long>()
            var lastMatchEnd = 0

            while (matcher.find()) {
                val min = matcher.group(1)?.toLongOrNull() ?: 0L
                val sec = matcher.group(2)?.toLongOrNull() ?: 0L
                val msPart = matcher.group(3)
                val ms = when {
                    msPart == null -> 0L
                    msPart.length == 2 -> (msPart.toLongOrNull() ?: 0L) * 10
                    else -> (msPart.toLongOrNull() ?: 0L)
                }
                val totalMs = (min * 60 + sec) * 1000 + ms
                timeStamps.add(totalMs)
                lastMatchEnd = matcher.end()
            }

            if (timeStamps.isNotEmpty()) {
                val text = trimmed.substring(lastMatchEnd).trim()
                if (text.isNotEmpty()) {
                    for (t in timeStamps) {
                        lines.add(LyricLine(timeMs = t, text = text))
                    }
                }
            }
        }

        return lines.sortedBy { it.timeMs }
    }

    fun findActiveIndex(lines: List<LyricLine>, currentMs: Long): Int {
        if (lines.isEmpty()) return -1
        var activeIndex = -1
        for (i in lines.indices) {
            if (lines[i].timeMs <= currentMs) {
                activeIndex = i
            } else {
                break
            }
        }
        return activeIndex
    }
}
