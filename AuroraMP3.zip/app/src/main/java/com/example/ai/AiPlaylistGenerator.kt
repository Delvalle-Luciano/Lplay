package com.example.ai

import com.example.BuildConfig
import com.example.model.Playlist
import com.example.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

data class AiPlaylistResult(
    val title: String,
    val description: String,
    val matchedSongs: List<Song>,
    val tags: List<String>
)

object AiPlaylistGenerator {

    suspend fun generatePlaylist(
        prompt: String,
        allSongs: List<Song>
    ): AiPlaylistResult = withContext(Dispatchers.Default) {
        // Subtle simulated neural thinking animation delay (gives authentic AI feel)
        delay(900)

        val cleanPrompt = prompt.lowercase().trim()

        // Analyze mood, tempo and genre intents
        val isEnergetic = cleanPrompt.contains("entren") || cleanPrompt.contains("gym") ||
                cleanPrompt.contains("cardio") || cleanPrompt.contains("corr") ||
                cleanPrompt.contains("energi") || cleanPrompt.contains("fiesta") ||
                cleanPrompt.contains("rapido") || cleanPrompt.contains("electro")

        val isRelaxing = cleanPrompt.contains("relaj") || cleanPrompt.contains("estudi") ||
                cleanPrompt.contains("dorm") || cleanPrompt.contains("calm") ||
                cleanPrompt.contains("medit") || cleanPrompt.contains("lluv") ||
                cleanPrompt.contains("lofi") || cleanPrompt.contains("paz")

        val isSynthwaveOrDrive = cleanPrompt.contains("synth") || cleanPrompt.contains("retro") ||
                cleanPrompt.contains("noche") || cleanPrompt.contains("conduc") ||
                cleanPrompt.contains("auto") || cleanPrompt.contains("neon") ||
                cleanPrompt.contains("cyber") || cleanPrompt.contains("80")

        val isCosmicOrAmbient = cleanPrompt.contains("cosmic") || cleanPrompt.contains("espac") ||
                cleanPrompt.contains("ambient") || cleanPrompt.contains("univer") ||
                cleanPrompt.contains("galax") || cleanPrompt.contains("astron")

        // Score and rank songs based on prompt affinity
        val scoredSongs = allSongs.map { song ->
            var score = 0.5f

            if (isEnergetic) {
                if (song.tempoBpm >= 110) score += 0.4f
                if (song.energyScore >= 0.7f) score += 0.3f
                if (song.genre == "Electrónica" || song.genre == "Synthwave") score += 0.3f
            }

            if (isRelaxing) {
                if (song.tempoBpm <= 85) score += 0.5f
                if (song.energyScore <= 0.45f) score += 0.4f
                if (song.genre == "Lo-Fi" || song.genre == "Ambient") score += 0.3f
            }

            if (isSynthwaveOrDrive) {
                if (song.genre == "Synthwave") score += 0.6f
                if (song.tempoBpm in 110..125) score += 0.3f
            }

            if (isCosmicOrAmbient) {
                if (song.genre == "Ambient" || song.genre == "Lo-Fi") score += 0.5f
            }

            // Word matching
            if (cleanPrompt.contains(song.genre.lowercase())) score += 0.4f
            if (cleanPrompt.contains(song.artist.lowercase())) score += 0.5f

            song to score
        }.sortedByDescending { it.second }

        val selected = scoredSongs.map { it.first }.take(maxOf(2, minOf(allSongs.size, 4)))

        // Dynamic creative title and description
        val (generatedTitle, generatedDesc, tags) = when {
            isEnergetic -> Triple(
                "AI Pulse: Alta Potencia ⚡",
                "Playlist generada por IA para elevar tus pulsaciones, entrenar al máximo y mantener el ritmo imparable.",
                listOf("Fitness", "BPM Alto", "Electrónica")
            )
            isRelaxing -> Triple(
                "AI Serenity: Zona de Enfoque 🌧️",
                "Atmósferas lo-fi y acordes cálidos curados por IA para maximizar la concentración y la paz mental.",
                listOf("Lo-Fi", "Estudio", "Relax")
            )
            isSynthwaveOrDrive -> Triple(
                "AI Neon Drive: 1984 Cyberpunk 🏎️",
                "Sintetizadores analógicos y líneas de bajo envolventes optimizadas para viajes nocturnos en 8D.",
                listOf("Synthwave", "Nocturno", "8D Audio")
            )
            isCosmicOrAmbient -> Triple(
                "AI Cosmos: Viaje Interestelar 🌌",
                "Ondas sonoras etéreas y resonancia profunda para desconectar y sumergirte en calma absoluta.",
                listOf("Ambient", "Espacial", "Inmersión")
            )
            else -> Triple(
                "AI Curation: $prompt".take(30),
                "Selección inteligente adaptada a tu estado de ánimo: \"$prompt\", optimizada con audio espacial.",
                listOf("IA Mix", "Personalizado", "Aura")
            )
        }

        AiPlaylistResult(
            title = generatedTitle,
            description = generatedDesc,
            matchedSongs = if (selected.isNotEmpty()) selected else allSongs.take(3),
            tags = tags
        )
    }
}
