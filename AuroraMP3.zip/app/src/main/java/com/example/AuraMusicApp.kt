package com.example

import android.app.Application
import com.example.audio.AudioPlayerEngine
import com.example.data.MusicRepository

class AuraMusicApp : Application() {

    lateinit var repository: MusicRepository
        private set

    lateinit var playerEngine: AudioPlayerEngine
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        repository = MusicRepository(this)
        playerEngine = AudioPlayerEngine(this)

        playerEngine.onTrackCompletedListener = { finishedSong ->
            repository.incrementPlayCount(finishedSong.id)
        }
    }

    override fun onTerminate() {
        super.onTerminate()
        playerEngine.release()
    }

    companion object {
        lateinit var instance: AuraMusicApp
            private set
    }
}
