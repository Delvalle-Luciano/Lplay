package com.example

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.QueueMusic
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.Playlist
import com.example.model.Song
import com.example.screens.AiPlaylistDialog
import com.example.screens.EqualizerSheet
import com.example.screens.LibraryScreen
import com.example.screens.MiniPlayer
import com.example.screens.NowPlayingScreen
import com.example.screens.PlaylistDetailScreen
import com.example.screens.PlaylistsScreen
import com.example.screens.SmartStorageDialog
import com.example.service.AudioPlayerService
import com.example.util.ShareHelper
import com.example.ui.theme.AuraAccentNeon
import com.example.ui.theme.AuraDarkBackground
import com.example.ui.theme.AuraDarkSurface
import com.example.ui.theme.AuraPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.widget.AuraAppWidgetProvider

enum class AppNavTab {
    LIBRARY,
    PLAYLISTS,
    EQUALIZER
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        setContent {
            MyApplicationTheme {
                MainAppScreen()
            }
        }
    }

    private fun startAudioService() {
        try {
            val intent = Intent(this, AudioPlayerService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        } catch (_: Exception) {}
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun MainAppScreen() {
        val app = AuraMusicApp.instance
        val repository = app.repository
        val playerEngine = app.playerEngine

        val songs by repository.songs.collectAsStateWithLifecycle()
        val playlists by repository.playlists.collectAsStateWithLifecycle()
        val storageStats by repository.storageStats.collectAsStateWithLifecycle()

        val currentSong by playerEngine.currentSong.collectAsStateWithLifecycle()
        val isPlaying by playerEngine.isPlaying.collectAsStateWithLifecycle()
        val currentPositionMs by playerEngine.currentPositionMs.collectAsStateWithLifecycle()
        val durationMs by playerEngine.durationMs.collectAsStateWithLifecycle()
        val equalizerState by playerEngine.equalizerState.collectAsStateWithLifecycle()
        val repeatMode by playerEngine.repeatMode.collectAsStateWithLifecycle()
        val isShuffle by playerEngine.isShuffle.collectAsStateWithLifecycle()
        val playbackSpeed by playerEngine.playbackSpeed.collectAsStateWithLifecycle()

        var currentTab by remember { mutableStateOf(AppNavTab.LIBRARY) }
        var selectedPlaylist by remember { mutableStateOf<Playlist?>(null) }
        var isNowPlayingOpen by remember { mutableStateOf(false) }
        var isAiCreatorOpen by remember { mutableStateOf(false) }
        var isStorageManagerOpen by remember { mutableStateOf(false) }
        var isEqualizerSheetOpen by remember { mutableStateOf(false) }

        // Android 13+ Notification permission request
        val notificationPermissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                startAudioService()
            }
        }

        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            startAudioService()
        }

        // Import MP3 file picker via SAF
        val importAudioLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri ->
            if (uri != null) {
                val imported = repository.importSongFromUri(uri)
                if (imported != null) {
                    Toast.makeText(this@MainActivity, "Canción \"${imported.title}\" importada con éxito", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "No se pudo importar el archivo de audio", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val dominantColor = currentSong?.let { Color(it.dominantColorHex) } ?: AuraPrimary

        // BackHandler logic
        BackHandler(enabled = isNowPlayingOpen || selectedPlaylist != null) {
            when {
                isNowPlayingOpen -> isNowPlayingOpen = false
                selectedPlaylist != null -> selectedPlaylist = null
            }
        }

        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(AuraDarkBackground),
            containerColor = AuraDarkBackground,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (!isNowPlayingOpen) {
                    NavigationBar(
                        containerColor = AuraDarkSurface,
                        contentColor = TextPrimary,
                        modifier = Modifier
                            .navigationBarsPadding()
                            .testTag("main_navigation_bar")
                    ) {
                        NavigationBarItem(
                            selected = currentTab == AppNavTab.LIBRARY,
                            onClick = {
                                currentTab = AppNavTab.LIBRARY
                                selectedPlaylist = null
                            },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == AppNavTab.LIBRARY) Icons.Filled.LibraryMusic else Icons.Outlined.LibraryMusic,
                                    contentDescription = "Biblioteca"
                                )
                            },
                            label = { Text("Biblioteca", fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = AuraAccentNeon,
                                selectedTextColor = AuraAccentNeon,
                                indicatorColor = AuraDarkBackground,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )

                        NavigationBarItem(
                            selected = currentTab == AppNavTab.PLAYLISTS,
                            onClick = {
                                currentTab = AppNavTab.PLAYLISTS
                                selectedPlaylist = null
                            },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == AppNavTab.PLAYLISTS) Icons.Filled.QueueMusic else Icons.Outlined.QueueMusic,
                                    contentDescription = "Listas"
                                )
                            },
                            label = { Text("Listas", fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = AuraAccentNeon,
                                selectedTextColor = AuraAccentNeon,
                                indicatorColor = AuraDarkBackground,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )

                        NavigationBarItem(
                            selected = currentTab == AppNavTab.EQUALIZER,
                            onClick = {
                                isEqualizerSheetOpen = true
                            },
                            icon = {
                                Icon(
                                    imageVector = if (equalizerState.is8DActive) Icons.Filled.GraphicEq else Icons.Outlined.GraphicEq,
                                    contentDescription = "Ecualizador"
                                )
                            },
                            label = { Text("Ecualizador & 8D", fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = AuraAccentNeon,
                                selectedTextColor = AuraAccentNeon,
                                indicatorColor = AuraDarkBackground,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = paddingValues.calculateBottomPadding())
            ) {
                // Main Content Screen
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                ) {
                    when {
                        selectedPlaylist != null -> {
                            PlaylistDetailScreen(
                                playlist = selectedPlaylist!!,
                                allSongs = songs,
                                onPlaySongInPlaylist = { list, idx ->
                                    playerEngine.playQueue(list, idx)
                                    startAudioService()
                                },
                                onRemoveSongFromPlaylist = { plId, songId ->
                                    repository.removeSongFromPlaylist(plId, songId)
                                    selectedPlaylist = playlists.find { it.id == plId }
                                },
                                onDeletePlaylist = { plId ->
                                    repository.deletePlaylist(plId)
                                    selectedPlaylist = null
                                },
                                onSharePlaylist = { pl, pSongs ->
                                    ShareHelper.sharePlaylist(this@MainActivity, pl, pSongs)
                                },
                                onBack = { selectedPlaylist = null }
                            )
                        }
                        currentTab == AppNavTab.LIBRARY -> {
                            LibraryScreen(
                                songs = songs,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                is8D = equalizerState.is8DActive,
                                playlists = playlists,
                                onPlaySong = { list, idx ->
                                    playerEngine.playQueue(list, idx)
                                    startAudioService()
                                },
                                onToggleFavorite = { repository.toggleFavorite(it) },
                                onAddSongToPlaylist = { plId, sId ->
                                    repository.addSongToPlaylist(plId, sId)
                                    Toast.makeText(this@MainActivity, "Canción agregada a la lista", Toast.LENGTH_SHORT).show()
                                },
                                onOpenAiCreator = { isAiCreatorOpen = true },
                                onOpenEqualizer = { isEqualizerSheetOpen = true },
                                onOpenStorageManager = { isStorageManagerOpen = true },
                                onImportMp3 = {
                                    importAudioLauncher.launch("audio/*")
                                },
                                onShareSong = { song ->
                                    ShareHelper.shareSong(this@MainActivity, song)
                                }
                            )
                        }
                        currentTab == AppNavTab.PLAYLISTS -> {
                            PlaylistsScreen(
                                playlists = playlists,
                                allSongs = songs,
                                onSelectPlaylist = { selectedPlaylist = it },
                                onPlayPlaylist = { pl ->
                                    val plSongs = pl.songIds.mapNotNull { id -> songs.find { it.id == id } }
                                    if (plSongs.isNotEmpty()) {
                                        playerEngine.playQueue(plSongs, 0)
                                        startAudioService()
                                    }
                                },
                                onCreatePlaylist = { name, desc ->
                                    repository.createPlaylist(name, desc, emptyList())
                                },
                                onDeletePlaylist = { repository.deletePlaylist(it) },
                                onOpenAiCreator = { isAiCreatorOpen = true },
                                onSharePlaylist = { pl ->
                                    ShareHelper.sharePlaylist(this@MainActivity, pl, songs)
                                }
                            )
                        }
                        else -> {}
                    }
                }

                // MiniPlayer Docked above bottom bar
                if (currentSong != null && !isNowPlayingOpen) {
                    MiniPlayer(
                        currentSong = currentSong,
                        isPlaying = isPlaying,
                        progressMs = currentPositionMs,
                        durationMs = durationMs,
                        is8D = equalizerState.is8DActive,
                        onTogglePlay = {
                            playerEngine.togglePlayPause()
                            startAudioService()
                        },
                        onSkipNext = {
                            playerEngine.skipNext()
                            startAudioService()
                        },
                        onOpenPlayer = { isNowPlayingOpen = true },
                        modifier = Modifier.align(Alignment.BottomCenter)
                    )
                }

                // Full NowPlayingScreen slide transition
                AnimatedVisibility(
                    visible = isNowPlayingOpen,
                    enter = slideInVertically(initialOffsetY = { it }),
                    exit = slideOutVertically(targetOffsetY = { it })
                ) {
                    NowPlayingScreen(
                        song = currentSong,
                        isPlaying = isPlaying,
                        currentPositionMs = currentPositionMs,
                        durationMs = durationMs,
                        is8D = equalizerState.is8DActive,
                        repeatMode = repeatMode,
                        isShuffle = isShuffle,
                        playbackSpeed = playbackSpeed,
                        onTogglePlay = {
                            playerEngine.togglePlayPause()
                            startAudioService()
                        },
                        onSeekTo = { playerEngine.seekTo(it) },
                        onSkipNext = {
                            playerEngine.skipNext()
                            startAudioService()
                        },
                        onSkipPrevious = {
                            playerEngine.skipPrevious()
                            startAudioService()
                        },
                        onToggleShuffle = { playerEngine.toggleShuffle() },
                        onCycleRepeat = { playerEngine.cycleRepeatMode() },
                        onCycleSpeed = {
                            val nextSpeed = when (playbackSpeed) {
                                1.0f -> 1.25f
                                1.25f -> 1.5f
                                1.5f -> 0.75f
                                else -> 1.0f
                            }
                            playerEngine.setPlaybackSpeed(nextSpeed)
                        },
                        onToggleFavorite = { repository.toggleFavorite(it) },
                        onOpenEqualizer = { isEqualizerSheetOpen = true },
                        onToggle8D = { playerEngine.set8DActive(it) },
                        onShareSong = { songToShare ->
                            ShareHelper.shareSong(this@MainActivity, songToShare)
                        },
                        onCollapse = { isNowPlayingOpen = false }
                    )
                }

                // Equalizer Modal Sheet
                if (isEqualizerSheetOpen) {
                    ModalBottomSheet(
                        onDismissRequest = { isEqualizerSheetOpen = false },
                        containerColor = AuraDarkBackground,
                        contentColor = TextPrimary
                    ) {
                        EqualizerSheet(
                            state = equalizerState,
                            dominantColor = dominantColor,
                            onPresetSelected = { playerEngine.setEqualizerPreset(it) },
                            onBandChanged = { band, lvl -> playerEngine.setBandLevel(band, lvl) },
                            onBassBoostChanged = { playerEngine.setBassBoost(it) },
                            onVirtualizerChanged = { playerEngine.setVirtualizer(it) },
                            on8DToggled = { playerEngine.set8DActive(it) },
                            on8DSpeedChanged = { playerEngine.set8DSpeed(it) },
                            onClose = { isEqualizerSheetOpen = false }
                        )
                    }
                }

                // AI Playlist Dialog
                if (isAiCreatorOpen) {
                    AiPlaylistDialog(
                        allSongs = songs,
                        onPlaylistCreated = { name, desc, songIds, isAi, prompt, playImmediately ->
                            val pl = repository.createPlaylist(name, desc, songIds, isAi, prompt)
                            if (playImmediately) {
                                val plSongs = songIds.mapNotNull { id -> songs.find { it.id == id } }
                                if (plSongs.isNotEmpty()) {
                                    playerEngine.playQueue(plSongs, 0)
                                    startAudioService()
                                }
                            }
                            Toast.makeText(this@MainActivity, "Playlist generada con IA guardada", Toast.LENGTH_SHORT).show()
                        },
                        onDismiss = { isAiCreatorOpen = false }
                    )
                }

                // Smart Storage Dialog
                if (isStorageManagerOpen) {
                    SmartStorageDialog(
                        stats = storageStats,
                        songs = songs,
                        onToggleSmartCache = { repository.setSmartCacheEnabled(it) },
                        onClearCache = {
                            repository.clearCache()
                            Toast.makeText(this@MainActivity, "Caché optimizada y liberada", Toast.LENGTH_SHORT).show()
                        },
                        onDismiss = { isStorageManagerOpen = false }
                    )
                }
            }
        }
    }
}
