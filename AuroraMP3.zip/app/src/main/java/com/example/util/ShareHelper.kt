package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.model.Playlist
import com.example.model.Song
import java.io.File

object ShareHelper {

    fun shareSong(context: Context, song: Song) {
        try {
            val shareText = "🎵 Escuchando: \"${song.title}\" de ${song.artist}\n" +
                    "Álbum: ${song.album} • Género: ${song.genre}\n" +
                    "🎧 ¡Escúchala en AuraMP3 con Ecualizador personalizado y modo Audio Espacial 8D!"

            val file = File(song.filePath)
            if (file.exists() && file.isFile) {
                val contentUri: Uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )

                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = if (song.filePath.endsWith(".wav", ignoreCase = true)) "audio/wav" else "audio/mpeg"
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    putExtra(Intent.EXTRA_SUBJECT, "${song.title} - ${song.artist}")
                    putExtra(Intent.EXTRA_TEXT, shareText)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }

                val chooser = Intent.createChooser(intent, "Compartir \"${song.title}\"").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            } else {
                // If audio file is content URI or virtual, share formatted recommendation
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "${song.title} - ${song.artist}")
                    putExtra(Intent.EXTRA_TEXT, shareText)
                }
                val chooser = Intent.createChooser(intent, "Compartir canción").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback plain text share
            try {
                val fallbackIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "🎵 \"${song.title}\" - ${song.artist} en AuraMP3")
                }
                context.startActivity(Intent.createChooser(fallbackIntent, "Compartir").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            } catch (err: Exception) {
                Toast.makeText(context, "No se pudo compartir la canción", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun sharePlaylist(context: Context, playlist: Playlist, songs: List<Song>) {
        try {
            val playlistSongs = playlist.songIds.mapNotNull { id -> songs.find { it.id == id } }
            val trackListStr = playlistSongs.mapIndexed { idx, s ->
                "${idx + 1}. ${s.title} — ${s.artist}"
            }.joinToString("\n")

            val message = "🎶 Lista de Reproducción: ${playlist.name}\n" +
                    (if (playlist.description.isNotBlank()) "${playlist.description}\n\n" else "\n") +
                    "Canciones (${playlistSongs.size}):\n" +
                    trackListStr +
                    "\n\n✨ Creada con AuraMP3 — Reproductor de MP3 y Audio 8D"

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Playlist: ${playlist.name}")
                putExtra(Intent.EXTRA_TEXT, message)
            }

            val chooser = Intent.createChooser(intent, "Compartir lista \"${playlist.name}\"").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "No se pudo compartir la lista", Toast.LENGTH_SHORT).show()
        }
    }
}
