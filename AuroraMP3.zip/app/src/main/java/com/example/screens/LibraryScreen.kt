package com.example.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SurroundSound
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Playlist
import com.example.model.Song
import com.example.ui.theme.AuraAccentAmber
import com.example.ui.theme.AuraAccentEmerald
import com.example.ui.theme.AuraAccentNeon
import com.example.ui.theme.AuraDarkBackground
import com.example.ui.theme.AuraDarkCard
import com.example.ui.theme.AuraDarkSurface
import com.example.ui.theme.AuraPrimary
import com.example.ui.theme.AuraSecondary
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

enum class LibraryFilter {
    ALL,
    FAVORITES,
    OFFLINE,
    SYNTHWAVE,
    LOFI,
    AMBIENT,
    ELECTRONIC
}

@Composable
fun LibraryScreen(
    songs: List<Song>,
    currentSong: Song?,
    isPlaying: Boolean,
    is8D: Boolean,
    playlists: List<Playlist>,
    onPlaySong: (List<Song>, Int) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onAddSongToPlaylist: (String, String) -> Unit,
    onOpenAiCreator: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onOpenStorageManager: () -> Unit,
    onImportMp3: () -> Unit,
    onShareSong: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(LibraryFilter.ALL) }

    // Quick filter & search logic
    val filteredSongs = remember(songs, searchQuery, selectedFilter) {
        songs.filter { song ->
            val matchesSearch = if (searchQuery.isBlank()) true else {
                song.title.contains(searchQuery, ignoreCase = true) ||
                        song.artist.contains(searchQuery, ignoreCase = true) ||
                        song.album.contains(searchQuery, ignoreCase = true) ||
                        song.genre.contains(searchQuery, ignoreCase = true)
            }

            val matchesFilter = when (selectedFilter) {
                LibraryFilter.ALL -> true
                LibraryFilter.FAVORITES -> song.isFavorite
                LibraryFilter.OFFLINE -> song.isOffline
                LibraryFilter.SYNTHWAVE -> song.genre.equals("Synthwave", ignoreCase = true)
                LibraryFilter.LOFI -> song.genre.equals("Lo-Fi", ignoreCase = true)
                LibraryFilter.AMBIENT -> song.genre.equals("Ambient", ignoreCase = true)
                LibraryFilter.ELECTRONIC -> song.genre.equals("Electrónica", ignoreCase = true)
            }

            matchesSearch && matchesFilter
        }
    }

    val mostPlayedSongs = remember(songs) {
        songs.sortedByDescending { it.playCount }.take(4)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("library_screen")
    ) {
        // TOP SEARCH BAR
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = {
                Text(
                    text = "Buscar por título, artista o género...",
                    color = TextTertiary,
                    fontSize = 13.sp
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Limpiar",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .testTag("search_text_field"),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = AuraDarkCard,
                unfocusedContainerColor = AuraDarkCard,
                focusedBorderColor = AuraPrimary,
                unfocusedBorderColor = DarkBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                cursorColor = AuraPrimary
            ),
            singleLine = true
        )

        // QUICK ACTION BUTTONS ROW
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                QuickActionButton(
                    icon = Icons.Default.AutoAwesome,
                    label = "Playlist IA",
                    color = AuraPrimary,
                    tag = "action_ai_playlist",
                    onClick = onOpenAiCreator
                )
            }
            item {
                QuickActionButton(
                    icon = Icons.Default.GraphicEq,
                    label = "Ecualizador & 8D",
                    color = AuraAccentNeon,
                    tag = "action_equalizer",
                    onClick = onOpenEqualizer
                )
            }
            item {
                QuickActionButton(
                    icon = Icons.Default.SdStorage,
                    label = "Almacenamiento",
                    color = AuraSecondary,
                    tag = "action_storage",
                    onClick = onOpenStorageManager
                )
            }
            item {
                QuickActionButton(
                    icon = Icons.Default.Add,
                    label = "Importar MP3",
                    color = AuraAccentAmber,
                    tag = "action_import_mp3",
                    onClick = onImportMp3
                )
            }
        }

        // FILTER CHIPS ROW
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item { FilterChip("Todos", selectedFilter == LibraryFilter.ALL) { selectedFilter = LibraryFilter.ALL } }
            item { FilterChip("Favoritos", selectedFilter == LibraryFilter.FAVORITES) { selectedFilter = LibraryFilter.FAVORITES } }
            item { FilterChip("Offline", selectedFilter == LibraryFilter.OFFLINE) { selectedFilter = LibraryFilter.OFFLINE } }
            item { FilterChip("Synthwave", selectedFilter == LibraryFilter.SYNTHWAVE) { selectedFilter = LibraryFilter.SYNTHWAVE } }
            item { FilterChip("Lo-Fi", selectedFilter == LibraryFilter.LOFI) { selectedFilter = LibraryFilter.LOFI } }
            item { FilterChip("Ambient", selectedFilter == LibraryFilter.AMBIENT) { selectedFilter = LibraryFilter.AMBIENT } }
            item { FilterChip("Electrónica", selectedFilter == LibraryFilter.ELECTRONIC) { selectedFilter = LibraryFilter.ELECTRONIC } }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // MOST PLAYED CAROUSEL (Show if not searching)
        if (searchQuery.isBlank() && selectedFilter == LibraryFilter.ALL && mostPlayedSongs.isNotEmpty()) {
            Column(modifier = Modifier.padding(top = 8.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Más Escuchadas",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Auto-caché offline",
                        color = AuraAccentEmerald,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(mostPlayedSongs) { song ->
                        Card(
                            modifier = Modifier
                                .width(130.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable {
                                    val idx = filteredSongs.indexOfFirst { it.id == song.id }
                                    if (idx >= 0) onPlaySong(filteredSongs, idx)
                                },
                            colors = CardDefaults.cardColors(containerColor = AuraDarkCard),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                val cover = if (song.coverDrawableRes != 0) song.coverDrawableRes else R.drawable.cover_synthwave
                                Image(
                                    painter = painterResource(id = cover),
                                    contentDescription = song.title,
                                    modifier = Modifier
                                        .size(114.dp)
                                        .clip(RoundedCornerShape(10.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = song.title,
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = song.artist,
                                    color = TextSecondary,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        // ALL TRACKS HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Canciones (${filteredSongs.size})",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.OfflinePin,
                    contentDescription = null,
                    tint = AuraAccentEmerald,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Modo Offline",
                    color = AuraAccentEmerald,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // MAIN SONGS LIST
        if (filteredSongs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No se encontraron canciones con los filtros seleccionados.",
                    color = TextTertiary,
                    fontSize = 13.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(filteredSongs, key = { _, s -> s.id }) { index, song ->
                    val isCurrent = currentSong?.id == song.id

                    SongListItem(
                        song = song,
                        isCurrent = isCurrent,
                        isPlaying = isPlaying && isCurrent,
                        is8D = is8D && isCurrent,
                        playlists = playlists,
                        onClick = { onPlaySong(filteredSongs, index) },
                        onToggleFavorite = { onToggleFavorite(song.id) },
                        onAddToPlaylist = { plId -> onAddSongToPlaylist(plId, song.id) },
                        onShareSong = onShareSong
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color,
    tag: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag(tag),
        color = AuraDarkCard,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun FilterChip(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (isSelected) AuraPrimary else Color.White.copy(alpha = 0.08f)
            )
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            color = if (isSelected) Color.White else TextSecondary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun SongListItem(
    song: Song,
    isCurrent: Boolean,
    isPlaying: Boolean,
    is8D: Boolean,
    playlists: List<Playlist>,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onAddToPlaylist: (String) -> Unit,
    onShareSong: (Song) -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isCurrent) Color(0xFF181E2E) else AuraDarkCard)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .testTag("song_item_${song.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Thumbnail with cover
        val cover = if (song.coverDrawableRes != 0) song.coverDrawableRes else R.drawable.cover_synthwave
        Box(
            modifier = Modifier.size(50.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = cover),
                contentDescription = song.title,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(10.dp)),
                contentScale = ContentScale.Crop
            )

            if (isCurrent && isPlaying) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Black.copy(alpha = 0.45f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Sonando",
                        tint = AuraAccentNeon,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Title and Artist
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = song.title,
                    color = if (isCurrent) AuraAccentNeon else TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )

                if (is8D) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(AuraAccentNeon.copy(alpha = 0.2f))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "8D",
                            color = AuraAccentNeon,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "${song.artist} • ${song.genre}",
                color = TextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // Favorite Toggle
        IconButton(
            onClick = onToggleFavorite,
            modifier = Modifier.size(36.dp)
        ) {
            Icon(
                imageVector = if (song.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "Favorito",
                tint = if (song.isFavorite) Color(0xFFFF3366) else TextTertiary,
                modifier = Modifier.size(20.dp)
            )
        }

        // More options 3-dots
        Box {
            IconButton(
                onClick = { showMenu = true },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Más opciones",
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }

            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { showMenu = false },
                modifier = Modifier.background(AuraDarkSurface)
            ) {
                DropdownMenuItem(
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null,
                            tint = AuraSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    text = {
                        Text(
                            text = "Compartir canción",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    onClick = {
                        onShareSong(song)
                        showMenu = false
                    }
                )

                playlists.forEach { pl ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = "Agregar a: ${pl.name}",
                                color = TextPrimary,
                                fontSize = 12.sp
                            )
                        },
                        onClick = {
                            onAddToPlaylist(pl.id)
                            showMenu = false
                        }
                    )
                }
            }
        }
    }
}
