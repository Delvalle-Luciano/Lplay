package com.example.model

data class EqualizerState(
    val isEnabled: Boolean = true,
    val presetIndex: Int = 0,
    val presetName: String = "Normal",
    // 5 bands: 60Hz, 230Hz, 910Hz, 3.6kHz, 14kHz (levels in dB from -10 to +10)
    val bandLevels: List<Int> = listOf(0, 0, 0, 0, 0),
    val bassBoostStrength: Int = 300, // 0 to 1000
    val virtualizerStrength: Int = 400, // 0 to 1000
    val is8DActive: Boolean = false,
    val spatialSpeedSeconds: Float = 10f, // time in seconds for a full 360 degree rotation
    val reverbPreset: Int = 0 // 0: None, 1: Room, 2: Hall, 3: Studio
)

data class EqualizerPreset(
    val name: String,
    val bandLevels: List<Int>,
    val bassBoost: Int,
    val virtualizer: Int
)

object EqualizerDefaults {
    val PRESETS = listOf(
        EqualizerPreset("Normal", listOf(0, 0, 0, 0, 0), 200, 200),
        EqualizerPreset("Bass Boost", listOf(8, 6, 2, 0, 1), 900, 300),
        EqualizerPreset("Pop", listOf(2, 4, 6, 4, 2), 400, 500),
        EqualizerPreset("Rock", listOf(6, 4, -2, 3, 7), 600, 400),
        EqualizerPreset("Electrónica", listOf(7, 5, 1, 4, 8), 850, 700),
        EqualizerPreset("Jazz", listOf(3, 2, 4, 3, 2), 300, 400),
        EqualizerPreset("Vocal", listOf(-2, 1, 7, 5, 2), 100, 300),
        EqualizerPreset("Acústica", listOf(4, 3, 2, 5, 6), 350, 450)
    )
}
