package com.example.model

data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val durationMs: Long,
    val filePath: String,
    val coverDrawableRes: Int = 0,
    val coverCustomUri: String? = null,
    val lyricsLrc: String = "",
    val playCount: Int = 0,
    val isFavorite: Boolean = false,
    val isOffline: Boolean = true,
    val dominantColorHex: Long = 0xFF7928CA,
    val secondaryColorHex: Long = 0xFF00DFD8,
    val energyScore: Float = 0.7f,
    val tempoBpm: Int = 120
)

data class LyricLine(
    val timeMs: Long,
    val text: String
)
