package com.example.model

data class Playlist(
    val id: String,
    val name: String,
    val description: String,
    val songIds: List<String>,
    val coverDrawableRes: Int = 0,
    val isAiGenerated: Boolean = false,
    val aiPrompt: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
