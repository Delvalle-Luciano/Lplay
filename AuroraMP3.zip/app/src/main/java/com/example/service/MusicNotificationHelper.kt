package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.model.Song

object MusicNotificationHelper {

    const val CHANNEL_ID = "aura_playback_channel"
    const val NOTIFICATION_ID = 1001

    const val ACTION_PLAY = "com.example.service.ACTION_PLAY"
    const val ACTION_PAUSE = "com.example.service.ACTION_PAUSE"
    const val ACTION_NEXT = "com.example.service.ACTION_NEXT"
    const val ACTION_PREV = "com.example.service.ACTION_PREV"
    const val ACTION_STOP = "com.example.service.ACTION_STOP"

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = context.getString(R.string.channel_desc)
                setShowBadge(false)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun buildNotification(
        context: Context,
        song: Song?,
        isPlaying: Boolean,
        is8D: Boolean
    ): Notification {
        createNotificationChannel(context)

        val contentIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            0,
            contentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val prevPending = PendingIntent.getService(
            context,
            1,
            Intent(context, AudioPlayerService::class.java).apply { action = ACTION_PREV },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val playPauseAction = if (isPlaying) ACTION_PAUSE else ACTION_PLAY
        val playPauseIcon = if (isPlaying) R.drawable.ic_widget_pause else R.drawable.ic_widget_play
        val playPauseTitle = if (isPlaying) "Pausar" else "Reproducir"
        val playPausePending = PendingIntent.getService(
            context,
            2,
            Intent(context, AudioPlayerService::class.java).apply { action = playPauseAction },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val nextPending = PendingIntent.getService(
            context,
            3,
            Intent(context, AudioPlayerService::class.java).apply { action = ACTION_NEXT },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = song?.title ?: "AuraMP3"
        val artist = if (song != null) {
            if (is8D) "${song.artist} • 8D Spatial" else "${song.artist} • ${song.album}"
        } else "Sin reproducción"

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_widget_play)
            .setContentTitle(title)
            .setContentText(artist)
            .setContentIntent(contentPendingIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(isPlaying)
            .addAction(R.drawable.ic_widget_prev, "Anterior", prevPending)
            .addAction(playPauseIcon, playPauseTitle, playPausePending)
            .addAction(R.drawable.ic_widget_next, "Siguiente", nextPending)

        if (song != null && song.coverDrawableRes != 0) {
            try {
                val bitmap = BitmapFactory.decodeResource(context.resources, song.coverDrawableRes)
                builder.setLargeIcon(bitmap)
            } catch (_: Exception) {}
        }

        return builder.build()
    }
}
