package com.example.service

import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import com.example.AuraMusicApp
import com.example.widget.AuraAppWidgetProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class AudioPlayerService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        MusicNotificationHelper.createNotificationChannel(this)

        serviceScope.launch {
            val app = AuraMusicApp.instance
            app.playerEngine.currentSong.collectLatest { song ->
                updateNotification()
                AuraAppWidgetProvider.updateAllWidgets(this@AudioPlayerService)
            }
        }

        serviceScope.launch {
            val app = AuraMusicApp.instance
            app.playerEngine.isPlaying.collectLatest {
                updateNotification()
                AuraAppWidgetProvider.updateAllWidgets(this@AudioPlayerService)
            }
        }

        serviceScope.launch {
            val app = AuraMusicApp.instance
            app.playerEngine.equalizerState.collectLatest {
                updateNotification()
                AuraAppWidgetProvider.updateAllWidgets(this@AudioPlayerService)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val engine = try { AuraMusicApp.instance.playerEngine } catch (_: Exception) { null }

        when (intent?.action) {
            MusicNotificationHelper.ACTION_PLAY -> engine?.togglePlayPause()
            MusicNotificationHelper.ACTION_PAUSE -> engine?.togglePlayPause()
            MusicNotificationHelper.ACTION_NEXT -> engine?.skipNext()
            MusicNotificationHelper.ACTION_PREV -> engine?.skipPrevious()
            MusicNotificationHelper.ACTION_STOP -> {
                engine?.togglePlayPause()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }

        updateNotification()
        return START_STICKY
    }

    private fun updateNotification() {
        try {
            val app = AuraMusicApp.instance
            val song = app.playerEngine.currentSong.value
            val isPlaying = app.playerEngine.isPlaying.value
            val is8D = app.playerEngine.equalizerState.value.is8DActive

            val notification = MusicNotificationHelper.buildNotification(this, song, isPlaying, is8D)
            if (isPlaying) {
                startForeground(MusicNotificationHelper.NOTIFICATION_ID, notification)
            } else {
                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                manager.notify(MusicNotificationHelper.NOTIFICATION_ID, notification)
            }
        } catch (_: Exception) {}
    }
}
