package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.AuraMusicApp
import com.example.MainActivity
import com.example.R
import com.example.model.Song

class AuraAppWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (widgetId in appWidgetIds) {
            updateWidgetView(context, appWidgetManager, widgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val engine = try { AuraMusicApp.instance.playerEngine } catch (_: Exception) { null }

        when (intent.action) {
            ACTION_TOGGLE_PLAY -> {
                engine?.togglePlayPause()
                updateAllWidgets(context)
            }
            ACTION_NEXT -> {
                engine?.skipNext()
                updateAllWidgets(context)
            }
            ACTION_PREV -> {
                engine?.skipPrevious()
                updateAllWidgets(context)
            }
        }
    }

    companion object {
        const val ACTION_TOGGLE_PLAY = "com.example.ACTION_TOGGLE_PLAY"
        const val ACTION_NEXT = "com.example.ACTION_NEXT"
        const val ACTION_PREV = "com.example.ACTION_PREV"

        fun updateAllWidgets(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val componentName = ComponentName(context, AuraAppWidgetProvider::class.java)
            val ids = appWidgetManager.getAppWidgetIds(componentName)
            if (ids.isNotEmpty()) {
                val intent = Intent(context, AuraAppWidgetProvider::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                context.sendBroadcast(intent)
            }
        }

        fun updateWidgetView(context: Context, appWidgetManager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_aura_player)
            val app = try { AuraMusicApp.instance } catch (_: Exception) { null }
            val currentSong: Song? = app?.playerEngine?.currentSong?.value
            val isPlaying: Boolean = app?.playerEngine?.isPlaying?.value ?: false
            val is8D: Boolean = app?.playerEngine?.equalizerState?.value?.is8DActive ?: false

            if (currentSong != null) {
                views.setTextViewText(R.id.widget_song_title, currentSong.title)
                val subtitle = if (is8D) "${currentSong.artist} • 8D Spatial" else "${currentSong.artist} • ${currentSong.genre}"
                views.setTextViewText(R.id.widget_song_artist, subtitle)
                if (currentSong.coverDrawableRes != 0) {
                    views.setImageViewResource(R.id.widget_album_art, currentSong.coverDrawableRes)
                }
            } else {
                views.setTextViewText(R.id.widget_song_title, "AuraMP3")
                views.setTextViewText(R.id.widget_song_artist, "Toca para reproducir")
                views.setImageViewResource(R.id.widget_album_art, R.drawable.cover_synthwave)
            }

            // Play/Pause button icon
            val playPauseRes = if (isPlaying) R.drawable.ic_widget_pause else R.drawable.ic_widget_play
            views.setImageViewResource(R.id.widget_btn_play_pause, playPauseRes)

            // Intent to launch MainActivity when tapping card
            val openAppIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val openAppPendingIntent = PendingIntent.getActivity(
                context, 0, openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, openAppPendingIntent)

            // Action PendingIntents
            val playIntent = Intent(context, AuraAppWidgetProvider::class.java).apply { action = ACTION_TOGGLE_PLAY }
            val playPending = PendingIntent.getBroadcast(
                context, 1, playIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_btn_play_pause, playPending)

            val nextIntent = Intent(context, AuraAppWidgetProvider::class.java).apply { action = ACTION_NEXT }
            val nextPending = PendingIntent.getBroadcast(
                context, 2, nextIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_btn_next, nextPending)

            val prevIntent = Intent(context, AuraAppWidgetProvider::class.java).apply { action = ACTION_PREV }
            val prevPending = PendingIntent.getBroadcast(
                context, 3, prevIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_btn_prev, prevPending)

            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }
}
