package com.example.audio

import android.content.Context
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.util.Log
import com.example.model.EqualizerDefaults
import com.example.model.EqualizerState
import com.example.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class RepeatMode {
    OFF,
    ALL,
    ONE
}

class AudioPlayerEngine(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Main + Job())

    private var mediaPlayer: MediaPlayer? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null

    private var positionJob: Job? = null
    private var spatial8DJob: Job? = null

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _queue = MutableStateFlow<List<Song>>(emptyList())
    val queue: StateFlow<List<Song>> = _queue.asStateFlow()

    private val _queueIndex = MutableStateFlow(-1)
    val queueIndex: StateFlow<Int> = _queueIndex.asStateFlow()

    private val _repeatMode = MutableStateFlow(RepeatMode.ALL)
    val repeatMode: StateFlow<RepeatMode> = _repeatMode.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _equalizerState = MutableStateFlow(EqualizerState())
    val equalizerState: StateFlow<EqualizerState> = _equalizerState.asStateFlow()

    // 8D angle in radians
    private var current8DAngle = 0.0

    // Callback on track finished
    var onTrackCompletedListener: ((Song) -> Unit)? = null

    fun playQueue(songs: List<Song>, startIndex: Int = 0) {
        if (songs.isEmpty()) return
        _queue.value = songs
        val validIndex = startIndex.coerceIn(0, songs.size - 1)
        _queueIndex.value = validIndex
        playSong(songs[validIndex])
    }

    fun playSong(song: Song) {
        _currentSong.value = song
        releasePlayer()

        try {
            val player = MediaPlayer()
            mediaPlayer = player

            if (song.filePath.startsWith("content://") || song.filePath.startsWith("file://")) {
                player.setDataSource(context, Uri.parse(song.filePath))
            } else {
                val f = File(song.filePath)
                if (f.exists()) {
                    player.setDataSource(f.absolutePath)
                } else {
                    Log.w("AudioPlayerEngine", "Song file does not exist: ${song.filePath}")
                }
            }

            player.setOnPreparedListener { mp ->
                _durationMs.value = mp.duration.toLong()
                setupAudioEffects(mp.audioSessionId)
                applyEqualizerState(_equalizerState.value)
                applyPlaybackSpeed(_playbackSpeed.value)
                mp.start()
                _isPlaying.value = true
                startPositionTicker()
                start8DSpatialLoop()
            }

            player.setOnCompletionListener {
                handleSongCompletion()
            }

            player.setOnErrorListener { _, what, extra ->
                Log.e("AudioPlayerEngine", "MediaPlayer error: what=$what, extra=$extra")
                _isPlaying.value = false
                false
            }

            player.prepareAsync()
        } catch (e: Exception) {
            Log.e("AudioPlayerEngine", "Error playing song: ${e.message}", e)
            _isPlaying.value = false
        }
    }

    fun togglePlayPause() {
        val player = mediaPlayer ?: return
        if (player.isPlaying) {
            player.pause()
            _isPlaying.value = false
            stopPositionTicker()
        } else {
            player.start()
            _isPlaying.value = true
            startPositionTicker()
            start8DSpatialLoop()
        }
    }

    fun seekTo(positionMs: Long) {
        mediaPlayer?.let { player ->
            player.seekTo(positionMs.toInt())
            _currentPositionMs.value = positionMs
        }
    }

    fun skipNext() {
        val q = _queue.value
        if (q.isEmpty()) return

        if (_isShuffle.value && q.size > 1) {
            var nextIdx = (q.indices).random()
            if (nextIdx == _queueIndex.value) {
                nextIdx = (nextIdx + 1) % q.size
            }
            _queueIndex.value = nextIdx
            playSong(q[nextIdx])
            return
        }

        val nextIdx = _queueIndex.value + 1
        if (nextIdx < q.size) {
            _queueIndex.value = nextIdx
            playSong(q[nextIdx])
        } else if (_repeatMode.value == RepeatMode.ALL) {
            _queueIndex.value = 0
            playSong(q[0])
        }
    }

    fun skipPrevious() {
        val q = _queue.value
        if (q.isEmpty()) return

        // If played more than 3 seconds, replay current
        if (_currentPositionMs.value > 3000) {
            seekTo(0)
            return
        }

        val prevIdx = _queueIndex.value - 1
        if (prevIdx >= 0) {
            _queueIndex.value = prevIdx
            playSong(q[prevIdx])
        } else if (_repeatMode.value == RepeatMode.ALL) {
            _queueIndex.value = q.size - 1
            playSong(q[prevIdx.coerceAtLeast(0)])
        } else {
            seekTo(0)
        }
    }

    fun toggleShuffle() {
        _isShuffle.value = !_isShuffle.value
    }

    fun cycleRepeatMode() {
        _repeatMode.value = when (_repeatMode.value) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        applyPlaybackSpeed(speed)
    }

    private fun applyPlaybackSpeed(speed: Float) {
        try {
            mediaPlayer?.let { player ->
                val params = player.playbackParams
                params.speed = speed
                player.playbackParams = params
            }
        } catch (e: Exception) {
            Log.w("AudioPlayerEngine", "Cannot apply playback speed: ${e.message}")
        }
    }

    // 8D Audio spatial toggle and speed
    fun set8DActive(active: Boolean) {
        _equalizerState.value = _equalizerState.value.copy(is8DActive = active)
        if (active) {
            start8DSpatialLoop()
        } else {
            spatial8DJob?.cancel()
            mediaPlayer?.setVolume(1.0f, 1.0f)
        }
    }

    fun set8DSpeed(seconds: Float) {
        _equalizerState.value = _equalizerState.value.copy(spatialSpeedSeconds = seconds.coerceIn(4f, 25f))
    }

    // Equalizer controls
    fun setEqualizerPreset(presetIndex: Int) {
        if (presetIndex in EqualizerDefaults.PRESETS.indices) {
            val preset = EqualizerDefaults.PRESETS[presetIndex]
            val newState = _equalizerState.value.copy(
                presetIndex = presetIndex,
                presetName = preset.name,
                bandLevels = preset.bandLevels,
                bassBoostStrength = preset.bassBoost,
                virtualizerStrength = preset.virtualizer
            )
            _equalizerState.value = newState
            applyEqualizerState(newState)
        }
    }

    fun setBandLevel(bandIndex: Int, levelDb: Int) {
        val bands = _equalizerState.value.bandLevels.toMutableList()
        if (bandIndex in bands.indices) {
            bands[bandIndex] = levelDb.coerceIn(-10, 10)
            val newState = _equalizerState.value.copy(
                presetIndex = -1,
                presetName = "Personalizado",
                bandLevels = bands
            )
            _equalizerState.value = newState
            applyEqualizerState(newState)
        }
    }

    fun setBassBoost(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        _equalizerState.value = _equalizerState.value.copy(bassBoostStrength = clamped)
        try {
            bassBoost?.let {
                if (it.strengthSupported) {
                    it.enabled = clamped > 0
                    it.setStrength(clamped.toShort())
                }
            }
        } catch (e: Exception) {
            Log.w("AudioPlayerEngine", "BassBoost error: ${e.message}")
        }
    }

    fun setVirtualizer(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        _equalizerState.value = _equalizerState.value.copy(virtualizerStrength = clamped)
        try {
            virtualizer?.let {
                if (it.strengthSupported) {
                    it.enabled = clamped > 0
                    it.setStrength(clamped.toShort())
                }
            }
        } catch (e: Exception) {
            Log.w("AudioPlayerEngine", "Virtualizer error: ${e.message}")
        }
    }

    private fun setupAudioEffects(sessionId: Int) {
        try {
            equalizer?.release()
            bassBoost?.release()
            virtualizer?.release()

            equalizer = Equalizer(0, sessionId).apply { enabled = true }
            bassBoost = BassBoost(0, sessionId).apply { enabled = true }
            virtualizer = Virtualizer(0, sessionId).apply { enabled = true }
        } catch (e: Exception) {
            Log.w("AudioPlayerEngine", "Hardware AudioFx unavailable or restricted: ${e.message}")
        }
    }

    private fun applyEqualizerState(state: EqualizerState) {
        try {
            val eq = equalizer ?: return
            if (eq.enabled) {
                val numBands = eq.numberOfBands.toInt()
                val minRange = eq.bandLevelRange[0]
                val maxRange = eq.bandLevelRange[1]

                for (i in 0 until minOf(numBands, state.bandLevels.size)) {
                    val dbLevel = state.bandLevels[i]
                    // Map -10dB..+10dB to minRange..maxRange mB (usually -1500 to +1500 mB)
                    val targetMb = (dbLevel * 100).coerceIn(minRange.toInt(), maxRange.toInt()).toShort()
                    eq.setBandLevel(i.toShort(), targetMb)
                }
            }

            bassBoost?.let {
                if (it.strengthSupported) {
                    it.enabled = state.bassBoostStrength > 0
                    it.setStrength(state.bassBoostStrength.toShort())
                }
            }

            virtualizer?.let {
                if (it.strengthSupported) {
                    it.enabled = state.virtualizerStrength > 0 || state.is8DActive
                    val strength = if (state.is8DActive) {
                        maxOf(state.virtualizerStrength, 750)
                    } else state.virtualizerStrength
                    it.setStrength(strength.toShort())
                }
            }
        } catch (e: Exception) {
            Log.w("AudioPlayerEngine", "Failed to apply EQ: ${e.message}")
        }
    }

    private fun start8DSpatialLoop() {
        spatial8DJob?.cancel()
        if (!_equalizerState.value.is8DActive) return

        spatial8DJob = scope.launch(Dispatchers.Default) {
            val intervalMs = 40L
            while (isActive && _isPlaying.value && _equalizerState.value.is8DActive) {
                val speed = _equalizerState.value.spatialSpeedSeconds.coerceAtLeast(2f)
                val deltaAngle = (2.0 * PI) * (intervalMs.toDouble() / 1000.0) / speed
                current8DAngle = (current8DAngle + deltaAngle) % (2.0 * PI)

                // 8D rotating audio:
                // Sound revolves in an elliptical circle around the head (left, front, right, behind)
                val panX = sin(current8DAngle) // -1.0 (left) to +1.0 (right)
                val depthY = cos(current8DAngle) // front vs back subtle volume attenuation

                // Binaural Head-Related Intensity Difference
                val leftFactor = (0.5 * (1.0 - panX)).toFloat().coerceIn(0.12f, 1.0f)
                val rightFactor = (0.5 * (1.0 + panX)).toFloat().coerceIn(0.12f, 1.0f)

                // Subtle volume distance modulation
                val distanceFactor = (0.85f + 0.15f * depthY.toFloat()).coerceIn(0.7f, 1.0f)

                val leftVol = leftFactor * distanceFactor
                val rightVol = rightFactor * distanceFactor

                mediaPlayer?.let { player ->
                    try {
                        player.setVolume(leftVol, rightVol)
                    } catch (_: Exception) {}
                }

                delay(intervalMs)
            }
        }
    }

    private fun startPositionTicker() {
        positionJob?.cancel()
        positionJob = scope.launch {
            while (isActive && _isPlaying.value) {
                mediaPlayer?.let { player ->
                    try {
                        if (player.isPlaying) {
                            _currentPositionMs.value = player.currentPosition.toLong()
                        }
                    } catch (_: Exception) {}
                }
                delay(150)
            }
        }
    }

    private fun stopPositionTicker() {
        positionJob?.cancel()
    }

    private fun handleSongCompletion() {
        _currentSong.value?.let { completedSong ->
            onTrackCompletedListener?.invoke(completedSong)
        }

        when (_repeatMode.value) {
            RepeatMode.ONE -> {
                seekTo(0)
                mediaPlayer?.start()
                _isPlaying.value = true
                startPositionTicker()
                start8DSpatialLoop()
            }
            RepeatMode.ALL -> {
                skipNext()
            }
            RepeatMode.OFF -> {
                if (_queueIndex.value < _queue.value.size - 1) {
                    skipNext()
                } else {
                    _isPlaying.value = false
                    seekTo(0)
                    stopPositionTicker()
                    spatial8DJob?.cancel()
                }
            }
        }
    }

    fun release() {
        releasePlayer()
        scope.launch {
            spatial8DJob?.cancel()
            positionJob?.cancel()
        }
    }

    private fun releasePlayer() {
        stopPositionTicker()
        spatial8DJob?.cancel()
        try {
            equalizer?.release()
            bassBoost?.release()
            virtualizer?.release()
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {}
        equalizer = null
        bassBoost = null
        virtualizer = null
        mediaPlayer = null
    }
}
