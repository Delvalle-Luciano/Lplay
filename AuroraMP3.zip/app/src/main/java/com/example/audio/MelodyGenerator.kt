package com.example.audio

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin

object MelodyGenerator {

    enum class TrackStyle {
        SYNTHWAVE,
        LOFI_CHILL,
        COSMIC_AMBIENT,
        ELECTRONIC_PULSE
    }

    fun ensureTrackFile(context: Context, style: TrackStyle): File {
        val audioDir = File(context.filesDir, "audio_tracks")
        if (!audioDir.exists()) audioDir.mkdirs()

        val fileName = when (style) {
            TrackStyle.SYNTHWAVE -> "neon_pulse.wav"
            TrackStyle.LOFI_CHILL -> "midnight_coffee.wav"
            TrackStyle.COSMIC_AMBIENT -> "nebula_drift.wav"
            TrackStyle.ELECTRONIC_PULSE -> "aurora_eclipse.wav"
        }

        val targetFile = File(audioDir, fileName)
        if (targetFile.exists() && targetFile.length() > 10000) {
            return targetFile
        }

        generateWavTrack(targetFile, style)
        return targetFile
    }

    private fun generateWavTrack(file: File, style: TrackStyle) {
        val sampleRate = 44100
        val durationSeconds = 36 // 36 seconds loop
        val numSamples = sampleRate * durationSeconds
        val numChannels = 2 // Stereo for true 8D spatial immersion
        val bytesPerSample = 2 // 16-bit PCM

        val dataSize = numSamples * numChannels * bytesPerSample
        val totalFileSize = 44 + dataSize

        FileOutputStream(file).use { fos ->
            // RIFF header
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray())
            header.putInt(totalFileSize - 8)
            header.put("WAVE".toByteArray())
            header.put("fmt ".toByteArray())
            header.putInt(16) // Subchunk1Size for PCM
            header.putShort(1.toShort()) // AudioFormat 1 = PCM
            header.putShort(numChannels.toShort())
            header.putInt(sampleRate)
            header.putInt(sampleRate * numChannels * bytesPerSample) // ByteRate
            header.putShort((numChannels * bytesPerSample).toShort()) // BlockAlign
            header.putShort(16.toShort()) // BitsPerSample
            header.put("data".toByteArray())
            header.putInt(dataSize)

            fos.write(header.array())

            // Write PCM audio samples in chunks to stay memory friendly for low-end devices
            val chunkSize = 4096
            val buffer = ByteBuffer.allocate(chunkSize * numChannels * bytesPerSample).order(ByteOrder.LITTLE_ENDIAN)

            // Musical chords and scales
            val rootFreqs = when (style) {
                TrackStyle.SYNTHWAVE -> listOf(130.81, 146.83, 164.81, 174.61) // C3, D3, E3, F3
                TrackStyle.LOFI_CHILL -> listOf(110.00, 130.81, 146.83, 98.00) // A2, C3, D3, G2
                TrackStyle.COSMIC_AMBIENT -> listOf(87.31, 110.00, 130.81, 98.00) // F2, A2, C3, G2
                TrackStyle.ELECTRONIC_PULSE -> listOf(130.81, 164.81, 196.00, 146.83) // C3, E3, G3, D3
            }

            var sampleIndex = 0
            while (sampleIndex < numSamples) {
                buffer.clear()
                val currentChunk = minOf(chunkSize, numSamples - sampleIndex)

                for (i in 0 until currentChunk) {
                    val s = sampleIndex + i
                    val t = s.toDouble() / sampleRate
                    val chordIdx = ((t / 4.0).toInt()) % rootFreqs.size
                    val baseFreq = rootFreqs[chordIdx]

                    var leftVal = 0.0
                    var rightVal = 0.0

                    when (style) {
                        TrackStyle.SYNTHWAVE -> {
                            // Arpeggiated bassline
                            val beatTime = t * (116.0 / 60.0)
                            val subBeat = (beatTime * 4).toInt() % 4
                            val arpMult = when (subBeat) {
                                0 -> 1.0
                                1 -> 1.5
                                2 -> 2.0
                                else -> 1.25
                            }
                            val bassFreq = baseFreq * arpMult
                            val bass = sin(2 * PI * bassFreq * t) * 0.4 + sin(4 * PI * bassFreq * t) * 0.15

                            // Smooth synth lead with stereo spread
                            val leadFreq = baseFreq * 2.0
                            val lead = sin(2 * PI * leadFreq * t) * 0.25 + sin(2 * PI * (leadFreq * 1.5) * t) * 0.15

                            // Kick drum punch on each beat
                            val beatFraction = beatTime - beatTime.toInt()
                            val kick = if (beatFraction < 0.15) {
                                val kickEnv = 1.0 - (beatFraction / 0.15)
                                sin(2 * PI * (60.0 + kickEnv * 90.0) * beatFraction) * kickEnv * 0.5
                            } else 0.0

                            leftVal = bass * 0.8 + lead * 0.9 + kick
                            rightVal = bass * 0.7 + lead * 0.6 + kick
                        }
                        TrackStyle.LOFI_CHILL -> {
                            // Warm rhodes chords with tremolo
                            val tremolo = 0.8 + 0.2 * sin(2 * PI * 4.0 * t)
                            val chordTone1 = sin(2 * PI * baseFreq * t) * 0.3
                            val chordTone2 = sin(2 * PI * (baseFreq * 1.25) * t) * 0.25
                            val chordTone3 = sin(2 * PI * (baseFreq * 1.5) * t) * 0.2
                            val chordTone4 = sin(2 * PI * (baseFreq * 1.875) * t) * 0.15
                            val chord = (chordTone1 + chordTone2 + chordTone3 + chordTone4) * tremolo

                            // Relaxed mellow piano note
                            val noteStep = ((t * 2).toInt()) % 4
                            val melodyFreq = baseFreq * when (noteStep) {
                                0 -> 2.0
                                1 -> 2.5
                                2 -> 3.0
                                else -> 2.25
                            }
                            val piano = sin(2 * PI * melodyFreq * t) * 0.25 * (1.0 - (t * 2 - (t * 2).toInt()))

                            leftVal = chord * 0.85 + piano * 0.4
                            rightVal = chord * 0.7 + piano * 0.85
                        }
                        TrackStyle.COSMIC_AMBIENT -> {
                            // Slow evolving pads & binaural drones
                            val slowLfo = sin(2 * PI * 0.15 * t)
                            val pad1 = sin(2 * PI * (baseFreq * 1.0) * t) * 0.35
                            val pad2 = sin(2 * PI * (baseFreq * 1.498) * t) * 0.25 // Fifth
                            val pad3 = sin(2 * PI * (baseFreq * 2.0) * t) * 0.2
                            val sparkle = sin(2 * PI * (baseFreq * 4.0 + slowLfo * 10) * t) * 0.15

                            leftVal = pad1 + pad2 * 0.6 + sparkle * 0.8
                            rightVal = pad1 * 0.7 + pad2 + sparkle * 0.3
                        }
                        TrackStyle.ELECTRONIC_PULSE -> {
                            // Dance pulse with stereo bass & rhythmic claps
                            val beatTime = t * (128.0 / 60.0)
                            val beatFraction = beatTime - beatTime.toInt()
                            val kick = if (beatFraction < 0.18) {
                                val env = 1.0 - (beatFraction / 0.18)
                                sin(2 * PI * (55.0 + env * 120.0) * beatFraction) * env * 0.6
                            } else 0.0

                            val offBeatFraction = (beatTime + 0.5) - (beatTime + 0.5).toInt()
                            val hiHat = if (offBeatFraction < 0.08) {
                                (sin(2 * PI * 6500.0 * t) + sin(2 * PI * 9200.0 * t)) * (1.0 - offBeatFraction / 0.08) * 0.18
                            } else 0.0

                            val leadFreq = baseFreq * 2.0
                            val lead = sin(2 * PI * leadFreq * t) * 0.25 + sin(4 * PI * leadFreq * t) * 0.12

                            leftVal = kick + lead * 0.9 + hiHat * 0.5
                            rightVal = kick + lead * 0.5 + hiHat * 0.9
                        }
                    }

                    // Soft clip to 16-bit PCM range [-32767, 32767]
                    val leftPcm = (leftVal.coerceIn(-1.0, 1.0) * 28000).toInt().toShort()
                    val rightPcm = (rightVal.coerceIn(-1.0, 1.0) * 28000).toInt().toShort()

                    buffer.putShort(leftPcm)
                    buffer.putShort(rightPcm)
                }

                fos.write(buffer.array(), 0, currentChunk * numChannels * bytesPerSample)
                sampleIndex += currentChunk
            }
        }
    }
}
