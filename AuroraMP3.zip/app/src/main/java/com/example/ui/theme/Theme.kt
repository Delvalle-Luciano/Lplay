package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AuraPrimary,
    onPrimary = Color.White,
    primaryContainer = AuraDarkSurfaceVariant,
    onPrimaryContainer = AuraAccentNeon,
    secondary = AuraSecondary,
    onSecondary = Color.Black,
    secondaryContainer = AuraDarkSurface,
    onSecondaryContainer = Color.White,
    tertiary = AuraTertiary,
    background = AuraDarkBackground,
    onBackground = TextPrimary,
    surface = AuraDarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = AuraDarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to sleek immersive dark mode for music experience
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
