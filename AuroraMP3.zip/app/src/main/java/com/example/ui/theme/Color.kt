package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AuraDarkBackground = Color(0xFF0A0D14)
val AuraDarkSurface = Color(0xFF121622)
val AuraDarkSurfaceVariant = Color(0xFF1B2132)
val AuraDarkCard = Color(0xFF161B29)

val AuraPrimary = Color(0xFF8B5CF6)
val AuraSecondary = Color(0xFF06B6D4)
val AuraTertiary = Color(0xFFEC4899)

val AuraAccentNeon = Color(0xFF00F5D4)
val AuraAccentAmber = Color(0xFFF59E0B)
val AuraAccentMagenta = Color(0xFFD946EF)
val AuraAccentEmerald = Color(0xFF10B981)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

val DarkBorder = Color(0x22FFFFFF)
